# English Dictionary
English Dictionary App

## Features
* Word Search
* TextToSpeech Words
* SQLite Database - Crud Operation
* AsyncTask
* Material Design
* Fragment Design 
* Search History 

## ScreenShot


https://github.com/ardakazanci/English-Dictionary/blob/master/Screenshot_1565040413.png
